package com.poolmaster.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*

private data class Ball(val x: Float, val y: Float, val color: Color, val number: Int)
private data class ShotPath(val points: List<Offset>, val label: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PoolMasterApp() }
    }
}

@Composable
fun PoolMasterApp() {
    var cue by remember { mutableStateOf(Offset(0.28f, 0.52f)) }
    var target by remember { mutableStateOf(Offset(0.70f, 0.40f)) }
    var aim by remember { mutableStateOf(Offset(0.78f, 0.68f)) }
    var showPath by remember { mutableStateOf(true) }
    var power by remember { mutableFloatStateOf(0.65f) }
    var status by remember { mutableStateOf("Toca la mesa para apuntar") }

    val path = remember(cue, aim) { calculatePath(cue, aim) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF55D6A0),
        background = Color(0xFF101714),
        surface = Color(0xFF19231E)
    )) {
        Column(
            Modifier.fillMaxSize().background(Color(0xFF101714)).padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("POOL MASTER", fontSize = 25.sp, fontWeight = FontWeight.Black,
                color = Color(0xFFECF5EF), letterSpacing = 2.sp)
            Text("SIMULADOR DE TRAYECTORIAS", fontSize = 11.sp,
                color = Color(0xFF8EA69A), letterSpacing = 1.5.sp)
            Spacer(Modifier.height(18.dp))

            BoxWithConstraints(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                val w = constraints.maxWidth.toFloat()
                val h = constraints.maxHeight.toFloat()
                Canvas(
                    Modifier.fillMaxWidth().aspectRatio(1.55f)
                        .pointerInput(w, h) {
                            detectTapGestures { p ->
                                val nx = ((p.x / size.width).coerceIn(0.08f, 0.92f))
                                val ny = ((p.y / size.height).coerceIn(0.12f, 0.88f))
                                aim = Offset(nx, ny)
                                status = "Dirección actualizada"
                            }
                        }
                ) {
                    val board = drawContext.size
                    val sx = board.width
                    val sy = board.height
                    val rail = 22f
                    drawRoundRect(Color(0xFF4B2B19), cornerRadius = androidx.compose.ui.geometry.CornerRadius(24f))
                    drawRoundRect(Color(0xFF0B392C), topLeft = Offset(rail, rail),
                        size = androidx.compose.ui.geometry.Size(sx-2*rail, sy-2*rail),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(16f))
                    // Cushion markers
                    for (i in 1..5) {
                        val x = rail + (sx-2*rail)*i/6f
                        drawCircle(Color(0xFFB9A27A), 2.5f, Offset(x, rail/2))
                        drawCircle(Color(0xFFB9A27A), 2.5f, Offset(x, sy-rail/2))
                    }
                    val r = min(sx, sy) * 0.027f
                    val pockets = listOf(
                        Offset(rail,rail), Offset(sx/2,rail), Offset(sx-rail,rail),
                        Offset(rail,sy-rail), Offset(sx/2,sy-rail), Offset(sx-rail,sy-rail)
                    )
                    pockets.forEach { drawCircle(Color(0xFF080D0B), r*1.55f, it) }

                    if (showPath) {
                        val pts = path.points.map { Offset(it.x*sx, it.y*sy) }
                        if (pts.size >= 2) {
                            for (i in 0 until pts.size-1) {
                                drawLine(Color(0xFF55D6A0), pts[i], pts[i+1],
                                    strokeWidth = 3.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f,7f)))
                            }
                            pts.drop(1).forEach { drawCircle(Color(0xFF55D6A0), 4f, it) }
                        }
                    }
                    drawLine(Color(0xFFFFD166), Offset(cue.x*sx,cue.y*sy),
                        Offset(aim.x*sx,aim.y*sy), strokeWidth = 2f, alpha = 0.8f)
                    drawBall(Offset(cue.x*sx,cue.y*sy), r, Color.White, "C")
                    drawBall(Offset(target.x*sx,target.y*sy), r, Color(0xFFE9B949), "8")
                    drawCircle(Color(0xFF55D6A0), 5f, Offset(aim.x*sx,aim.y*sy))
                }
            }

            Spacer(Modifier.height(12.dp))
            Text(status, color = Color(0xFFB6C9BE), fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Potencia", color = Color.White, fontSize = 14.sp)
                Spacer(Modifier.width(12.dp))
                Slider(value = power, onValueChange = { power = it }, modifier = Modifier.weight(1f))
                Text("${(power*100).roundToInt()}%", color = Color(0xFF55D6A0), fontWeight = FontWeight.Bold)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { showPath = !showPath }, modifier = Modifier.weight(1f)) {
                    Text(if (showPath) "Ocultar línea" else "Mostrar línea")
                }
                Button(onClick = {
                    val dx = aim.x-cue.x
                    val dy = aim.y-cue.y
                    val len = sqrt(dx*dx+dy*dy).coerceAtLeast(0.001f)
                    cue = Offset((cue.x + dx/len*0.16f*power).coerceIn(0.08f,0.92f),
                        (cue.y + dy/len*0.16f*power).coerceIn(0.12f,0.88f))
                    status = "Simulación aplicada · potencia ${(power*100).roundToInt()}%"
                }, modifier = Modifier.weight(1f)) { Text("Simular tiro") }
                OutlinedButton(onClick = {
                    cue = Offset(0.28f,0.52f); target = Offset(0.70f,0.40f)
                    aim = Offset(0.78f,0.68f); power = 0.65f
                    status = "Mesa reiniciada"
                }, modifier = Modifier.weight(1f)) { Text("Reiniciar") }
            }
            Spacer(Modifier.height(10.dp))
            Text("Versión prototipo 0.1.0 · Mesa de práctica independiente",
                color = Color(0xFF71877B), fontSize = 10.sp)
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawBall(
    center: Offset, radius: Float, color: Color, text: String
) {
    drawCircle(Color.Black.copy(alpha = 0.35f), radius*1.12f, center + Offset(1.5f,2f))
    drawCircle(color, radius, center)
    drawCircle(Color.White.copy(alpha = 0.55f), radius*0.28f, center + Offset(-radius*0.25f,-radius*0.25f))
    drawContext.canvas.nativeCanvas.apply {
        val paint = android.graphics.Paint().apply {
            this.color = android.graphics.Color.BLACK
            textAlign = android.graphics.Paint.Align.CENTER
            textSize = radius*0.9f
            isFakeBoldText = true
            isAntiAlias = true
        }
        drawText(text, center.x, center.y + radius*0.32f, paint)
    }
}

private fun calculatePath(start: Offset, aim: Offset): ShotPath {
    val dx = aim.x-start.x
    val dy = aim.y-start.y
    val len = sqrt(dx*dx+dy*dy).coerceAtLeast(0.001f)
    val ux = dx/len
    val uy = dy/len
    val tCandidates = mutableListOf<Float>()
    if (ux > 0) tCandidates += (0.92f-start.x)/ux else if (ux < 0) tCandidates += (0.08f-start.x)/ux
    if (uy > 0) tCandidates += (0.88f-start.y)/uy else if (uy < 0) tCandidates += (0.12f-start.y)/uy
    val t = tCandidates.filter { it > 0 }.minOrNull() ?: 0.5f
    val hit = Offset((start.x+ux*t).coerceIn(0.08f,0.92f),(start.y+uy*t).coerceIn(0.12f,0.88f))
    val reflectedX = hit.x <= 0.081f || hit.x >= 0.919f
    val reflectedY = hit.y <= 0.121f || hit.y >= 0.879f
    val rx = if (reflectedX) -ux else ux
    val ry = if (reflectedY) -uy else uy
    val secondT = if (rx > 0) (0.92f-hit.x)/rx else if (rx < 0) (0.08f-hit.x)/rx
        else if (ry > 0) (0.88f-hit.y)/ry else (0.12f-hit.y)/ry
    val end = Offset((hit.x+rx*secondT).coerceIn(0.08f,0.92f),
        (hit.y+ry*secondT).coerceIn(0.12f,0.88f))
    return ShotPath(listOf(start,hit,end), "Trayectoria estimada")
}
