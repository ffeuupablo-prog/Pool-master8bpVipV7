# Pool Master — prototipo Android 0.1.0

Proyecto inicial en Kotlin + Jetpack Compose.

## Qué incluye
- Mesa de billar dibujada con Canvas.
- Bola blanca y bola objetivo de demostración.
- Tocar la mesa para cambiar la dirección de apuntado.
- Línea de trayectoria estimada y rebote geométrico simple.
- Control de potencia, simulación visual y reinicio.

## Abrir
1. Instala Android Studio en Windows.
2. Descomprime el ZIP.
3. En Android Studio, selecciona **Open** y elige la carpeta `PoolMaster`.
4. Espera la sincronización de Gradle.
5. Conecta el teléfono con depuración USB o usa un emulador.
6. Pulsa Run.

## Estado y límites
Es un prototipo educativo independiente. La línea es una estimación geométrica 2D, no una predicción física calibrada ni un analizador de partidas reales. No interactúa con otros juegos ni automatiza partidas.
